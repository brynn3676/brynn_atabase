<?php

session_start();
error_reporting(0);
include('includes/dbconnection.php');

?>
<div class=" row card-body">
  <?php
  $eid2=$_POST['edit_id2'];
  $ret2=mysqli_query($con,"select * from  membership where id='$eid2'");
  while ($row=mysqli_fetch_array($ret2))
  {
    ?>
    <div class="col-md-4">
      <img src="studentimages/<?php echo htmlentities($row['studentImage']);?>" width="100" height="100">
    </div>
    <div class="col-md-8">
      <table>
         <tr>
          <th>Membership Number</th>
          <td>&nbsp;<?php  echo $row['twu_number'];?></td>
        </tr>
        <tr>
          <th>Names</th>
          <td><?php  echo $row['name'];?></td>
        </tr>
        <tr>
          <th>Date of Birth</th>
          <td><?php  echo $row['dob'];?></td>
        </tr>
        <tr>
          <th>Company.</th>
          <td>0<?php  echo $row['company'];?></td>
        </tr>
      </table>
    </div>
    <?php
  } ?>
</div>
