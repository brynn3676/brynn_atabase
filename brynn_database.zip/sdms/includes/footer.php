<footer class="main-footer">
  <strong>Copyright &copy; <script>document.write(new Date().getFullYear());</script> <a href="https://twughana.org">Timber and Woodworkes Union OF TUC Ghana</a>.</strong>
  All rights reserved.
</footer>
